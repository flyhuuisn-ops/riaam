import { useState } from 'react';
import { X, Edit3, Trash2, AlertCircle, Loader2 } from 'lucide-react';
import { updateUsername, deleteUser, type AppUser } from '@/lib/auth';

interface UserSettingsModalProps {
  user: AppUser;
  onUpdate: (newUsername: string) => void;
  onDelete: () => void;
  onClose: () => void;
}

export default function UserSettingsModal({ user, onUpdate, onDelete, onClose }: UserSettingsModalProps) {
  const [mode, setMode] = useState<'menu' | 'edit' | 'delete'>('menu');
  const [newUsername, setNewUsername] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const validateUsername = (u: string): boolean => {
    return /^[a-z0-9._]+$/.test(u);
  };

  const handleEdit = async () => {
    setError('');
    const handle = newUsername.trim().toLowerCase();
    if (!handle) {
      setError('يرجى إدخال اليوزر الجديد');
      return;
    }
    if (!validateUsername(handle)) {
      setError('اليوزر يجب أن يحتوي على أحرف إنجليزية أو أرقام أو نقاط أو _ فقط');
      return;
    }
    if (handle === user.username) {
      setError('اليوزر الجديد مطابق لليوزر الحالي');
      return;
    }

    setLoading(true);
    try {
      const { success, error: err } = await updateUsername(user.id, handle);
      if (!success || err) {
        setError(err || 'حدث خطأ أثناء التعديل');
      } else {
        onUpdate(handle);
      }
    } catch {
      setError('حدث خطأ غير متوقع');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    setLoading(true);
    setError('');
    try {
      const { success, error: err } = await deleteUser(user.id, user.username);
      if (!success || err) {
        setError(err || 'حدث خطأ أثناء الحذف');
      } else {
        onDelete();
      }
    } catch {
      setError('حدث خطأ غير متوقع');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 animate-fade-in"
        onClick={onClose}
      />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md p-6 bg-night-900 border border-night-600 rounded-2xl shadow-2xl animate-slide-up">
        {/* header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-white">
            {mode === 'menu' && 'إعدادات اليوزر'}
            {mode === 'edit' && 'تعديل اليوزر'}
            {mode === 'delete' && 'حذف اليوزر'}
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-night-700 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* menu mode */}
        {mode === 'menu' && (
          <div className="space-y-3">
            <div className="p-3 bg-night-850 rounded-xl border border-night-700 mb-4">
              <p className="text-sm text-gray-400">اليوزر الحالي</p>
              <p className="text-lg font-mono text-white mt-1" dir="ltr">{user.username}</p>
            </div>
            <button
              onClick={() => setMode('edit')}
              className="w-full flex items-center gap-3 p-4 bg-night-850 hover:bg-night-800 border border-night-700 hover:border-rose-500/30 rounded-xl text-gray-200 hover:text-white transition-all"
            >
              <Edit3 className="w-5 h-5 text-rose-300" />
              <span className="font-medium">تعديل اليوزر</span>
              <span className="text-xs text-gray-500 mr-auto">لا يحذف الرسائل</span>
            </button>
            <button
              onClick={() => setMode('delete')}
              className="w-full flex items-center gap-3 p-4 bg-night-850 hover:bg-red-500/10 border border-night-700 hover:border-red-500/30 rounded-xl text-gray-200 hover:text-red-300 transition-all"
            >
              <Trash2 className="w-5 h-5 text-red-400" />
              <span className="font-medium">حذف اليوزر</span>
              <span className="text-xs text-gray-500 mr-auto">يحذف جميع البيانات</span>
            </button>
          </div>
        )}

        {/* edit mode */}
        {mode === 'edit' && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-1.5">اليوزر الجديد</label>
              <input
                type="text"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                placeholder="new_username"
                className="w-full h-12 px-4 bg-night-850 border border-night-600 rounded-xl text-white placeholder-gray-600 focus:border-rose-400 focus:outline-none transition-colors font-mono"
                dir="ltr"
              />
              <p className="text-xs text-gray-600 mt-1.5">أحرف إنجليزية، أرقام، نقاط، و _ فقط. لن تتأثر رسائلك.</p>
            </div>
            {error && (
              <div className="flex items-start gap-2 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-300 text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}
            <div className="flex gap-2">
              <button
                onClick={() => setMode('menu')}
                className="flex-1 h-12 bg-night-800 border border-night-600 text-gray-300 rounded-xl hover:bg-night-700 transition-colors font-medium"
              >
                رجوع
              </button>
              <button
                onClick={handleEdit}
                disabled={loading}
                className="flex-1 h-12 bg-gradient-to-r from-rose-500 to-rose-600 text-white rounded-xl hover:from-rose-400 hover:to-rose-500 transition-all disabled:opacity-50 font-bold flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'حفظ التعديل'}
              </button>
            </div>
          </div>
        )}

        {/* delete mode */}
        {mode === 'delete' && (
          <div className="space-y-4">
            <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
              <p className="text-red-300 text-sm font-medium mb-2">تحذير: لا يمكن التراجع</p>
              <p className="text-gray-300 text-sm">
                سيتم حذف اليوزر <span className="font-mono text-white" dir="ltr">{user.username}</span> وجميع الرسائل المرتبطة به نهائياً.
              </p>
            </div>
            {error && (
              <div className="flex items-start gap-2 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-300 text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}
            <div className="flex gap-2">
              <button
                onClick={() => setMode('menu')}
                className="flex-1 h-12 bg-night-800 border border-night-600 text-gray-300 rounded-xl hover:bg-night-700 transition-colors font-medium"
              >
                رجوع
              </button>
              <button
                onClick={handleDelete}
                disabled={loading}
                className="flex-1 h-12 bg-red-500/20 border border-red-500/40 text-red-300 rounded-xl hover:bg-red-500/30 transition-all disabled:opacity-50 font-bold flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'حذف نهائي'}
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
