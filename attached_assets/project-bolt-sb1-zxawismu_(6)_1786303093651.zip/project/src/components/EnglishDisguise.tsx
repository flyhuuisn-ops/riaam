import { BookOpen, ExternalLink, Search, Globe, Volume2, GraduationCap } from 'lucide-react';

const RESOURCES = [
  {
    name: 'YouGlish',
    description: 'تعلم النطق الإنجليزي من خلال آلاف الفيديوهات الواقعية',
    url: 'https://youglish.com',
    icon: Volume2,
  },
  {
    name: 'LanGeek',
    description: 'منصة شاملة لتعلم المفردات والقواعد الإنجليزية',
    url: 'https://langeek.co',
    icon: GraduationCap,
  },
  {
    name: 'Google Translate',
    description: 'ترجمة فورية بين العربية والإنجليزية',
    url: 'https://translate.google.com',
    icon: Globe,
  },
  {
    name: 'Reverso Context',
    description: 'ترجمة الكلمات في سياق جمل حقيقية',
    url: 'https://context.reverso.net/translation',
    icon: Search,
  },
];

const VOCABULARY = [
  { word: 'Serendipity', meaning: 'صدفة جميلة', example: 'Meeting you was pure serendipity.' },
  { word: 'Resilient', meaning: 'مرن، قادر على التعافي', example: 'She is resilient in difficult times.' },
  { word: 'Eloquent', meaning: 'بليغ، فصيح', example: 'He gave an eloquent speech.' },
  { word: 'Nostalgia', meaning: 'حنين إلى الماضي', example: 'A feeling of nostalgia washed over her.' },
  { word: 'Epiphany', meaning: 'إدراك مفاجئ', example: 'He had an epiphany about his life.' },
  { word: 'Quintessential', meaning: 'نموذجي، مثالي', example: 'The quintessential English afternoon tea.' },
  { word: 'Mellifluous', meaning: 'عذب الصوت', example: 'Her mellifluous voice filled the room.' },
  { word: 'Ephemeral', meaning: 'قصير العمر، زائل', example: 'Beauty is ephemeral but art endures.' },
];

const PHRASES = [
  'Break the ice — كسر الجمود في موقف اجتماعي',
  'Piece of cake — أمر سهل جداً',
  'Hit the books — يذاكر بجد',
  'Under the weather — يشعر بالتوعك',
  'Cost an arm and a leg — مكلف جداً',
  'Once in a blue moon — نادراً جداً',
  'A blessing in disguise — نعمة في ثوب نقمة',
  'Let the cat out of the bag — يفشي سراً',
];

export default function EnglishDisguise() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-blue-50" dir="rtl">
      {/* header */}
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-5 flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">تعلّم الإنجليزية</h1>
            <p className="text-sm text-slate-500">منصتك المجانية لإتقان اللغة الإنجليزية</p>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-10">
        {/* resources */}
        <section>
          <h2 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-blue-600" />
            مواقع تعليمية موثوقة
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {RESOURCES.map((r) => {
              const Icon = r.icon;
              return (
                <a
                  key={r.name}
                  href={r.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-start gap-3 p-5 bg-white rounded-2xl border border-slate-200 hover:border-blue-300 hover:shadow-md transition-all"
                >
                  <div className="w-11 h-11 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0 group-hover:bg-blue-100 transition-colors">
                    <Icon className="w-5 h-5 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-bold text-slate-800">{r.name}</h3>
                      <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                    </div>
                    <p className="text-sm text-slate-500 mt-1">{r.description}</p>
                  </div>
                </a>
              );
            })}
          </div>
        </section>

        {/* vocabulary */}
        <section>
          <h2 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-blue-600" />
            مفردات اليوم
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {VOCABULARY.map((v) => (
              <div
                key={v.word}
                className="p-4 bg-white rounded-xl border border-slate-200 hover:shadow-sm transition-shadow"
              >
                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-bold text-slate-800" dir="ltr">{v.word}</h3>
                  <span className="text-sm text-slate-500">{v.meaning}</span>
                </div>
                <p className="text-sm text-slate-400 italic" dir="ltr">{v.example}</p>
              </div>
            ))}
          </div>
        </section>

        {/* phrases */}
        <section>
          <h2 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
            <Globe className="w-5 h-5 text-blue-600" />
            عبارات شائعة
          </h2>
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
            {PHRASES.map((p, i) => (
              <div
                key={i}
                className={`px-5 py-3.5 text-sm text-slate-600 ${
                  i !== PHRASES.length - 1 ? 'border-b border-slate-100' : ''
                }`}
              >
                {p}
              </div>
            ))}
          </div>
        </section>

        <footer className="text-center py-6 text-slate-400 text-sm">
          تعلّم الإنجليزية خطوة بخطوة — استمر في التعلم كل يوم
        </footer>
      </main>
    </div>
  );
}
