import { useState, useEffect, useRef } from 'react';
import { X, Send, Maximize2, Minimize2, DoorOpen, BookOpen } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { sendNotification } from '@/lib/notifications';
import { type AppUser } from '@/lib/auth';

interface Message {
  id: string;
  content: string;
  sender: 'riyam' | 'jojo';
  created_at: string;
  username: string;
}

interface ChatWindowProps {
  user: AppUser;
  onClose: () => void;
  onPanic: () => void;
  onDisguise: () => void;
}

export default function ChatWindow({ user, onClose, onPanic, onDisguise }: ChatWindowProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [fullscreen, setFullscreen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [statusMsg, setStatusMsg] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);

  useEffect(() => {
    fetchMessages();
    subscribeMessages();

    return () => {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user.username]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const showStatus = (msg: string) => {
    setStatusMsg(msg);
    setTimeout(() => setStatusMsg(''), 5000);
  };

  const fetchMessages = async () => {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('username', user.username)
      .order('created_at', { ascending: true });

    if (error) {
      console.error('Error fetching messages:', error);
    } else if (data) {
      setMessages(data as Message[]);
    }
    setLoading(false);
  };

  const subscribeMessages = () => {
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current);
    }

    channelRef.current = supabase
      .channel(`messages-realtime-${user.username}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages' },
        (payload) => {
          const newMsg = payload.new as Message;
          if (newMsg.username === user.username) {
            setMessages((prev) => {
              if (prev.some((m) => m.id === newMsg.id)) return prev;
              return [...prev, newMsg];
            });
          }
        }
      )
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'messages' },
        () => {
          setMessages([]);
        }
      )
      .subscribe();
  };

  const handleSend = async () => {
    const trimmed = input.trim();
    if (!trimmed) return;

    setInput('');

    const { data, error } = await supabase
      .from('messages')
      .insert({ content: trimmed, sender: 'riyam', username: user.username })
      .select()
      .single();

    if (error) {
      console.error('Error sending message:', error);
      setInput(trimmed);
    } else if (data) {
      setMessages((prev) => {
        if (prev.some((m) => m.id === data.id)) return prev;
        return [...prev, data as Message];
      });
      await sendNotification('message', { messagePreview: trimmed, username: user.username });
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const formatTime = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
  };

  // The other person's display name - in this 2-person app, show the partner's name
  // "jojo" is the site owner; the visitor sees "jojo" as the other person
  // If the logged-in user IS jojo, they'd see the other person's name
  const otherDisplayName = user.username === 'jojo' ? 'ريام' : 'جوجو';

  return (
    <>
      {/* backdrop */}
      <div
        className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 animate-fade-in"
        onClick={onClose}
      />

      {/* chat window */}
      <div
        className={`fixed z-50 flex flex-col bg-night-900 border border-night-600 shadow-2xl animate-slide-up ${
          fullscreen
            ? 'inset-0 rounded-none'
            : 'bottom-4 left-4 right-4 top-auto sm:left-1/2 sm:right-auto sm:top-1/2 sm:bottom-auto sm:-translate-x-1/2 sm:-translate-y-1/2 w-full sm:w-[440px] h-[600px] max-h-[85vh] rounded-2xl'
        }`}
      >
        {/* header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-night-700 bg-night-850/80 backdrop-blur-xl rounded-t-2xl flex-shrink-0 gap-2">
          {/* left: other user's name + security buttons */}
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-sm font-bold text-white truncate">{otherDisplayName}</span>
            <div className="flex items-center gap-1 flex-shrink-0">
              <button
                onClick={onDisguise}
                title="تمويه سريع (F3)"
                className="w-8 h-8 rounded-lg bg-blue-500/15 border border-blue-400/40 hover:bg-blue-500/30 flex items-center justify-center transition-all"
              >
                <BookOpen className="w-4 h-4 text-blue-300" />
              </button>
              <button
                onClick={onPanic}
                title="طوارئ (Esc)"
                className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-400/40 hover:bg-amber-500/30 flex items-center justify-center transition-all"
              >
                <DoorOpen className="w-4 h-4 text-amber-300" />
              </button>
            </div>
          </div>

          {/* right: window controls */}
          <div className="flex items-center gap-1 flex-shrink-0">
            <button
              onClick={() => setFullscreen(!fullscreen)}
              className="w-8 h-8 rounded-lg hover:bg-night-700 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
              title={fullscreen ? 'تصغير' : 'ملء الشاشة'}
            >
              {fullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg hover:bg-rose-500/15 flex items-center justify-center text-gray-400 hover:text-rose-400 transition-colors"
              title="إغلاق"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* messages */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <div className="text-gray-500 text-sm">جاري التحميل...</div>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center gap-2">
              <p className="text-gray-400 text-sm">لا توجد رسائل بعد</p>
              <p className="text-gray-600 text-xs">اكتب رسالة واضغطي إرسال</p>
            </div>
          ) : (
            messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === 'riyam' ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[75%] px-4 py-2.5 rounded-2xl ${
                    msg.sender === 'riyam'
                      ? 'bg-rose-500/15 border border-rose-500/20 text-gray-100 rounded-bl-md'
                      : 'bg-night-700 border border-night-600 text-gray-100 rounded-br-md'
                  }`}
                >
                  <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{msg.content}</p>
                  <p className="text-[10px] text-gray-500 mt-1 text-left" dir="ltr">
                    {formatTime(msg.created_at)}
                  </p>
                </div>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* status message */}
        {statusMsg && (
          <div className="px-4 py-2 text-center text-xs text-gray-400 animate-fade-in">
            {statusMsg}
          </div>
        )}

        {/* input */}
        <div className="p-3 border-t border-night-700 bg-night-850/80 backdrop-blur-xl rounded-b-2xl flex-shrink-0">
          <div className="flex items-center gap-2">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="اكتب رسالتك..."
              className="flex-1 h-11 px-4 bg-night-800 border border-night-600 rounded-xl text-white text-sm placeholder-gray-500 focus:border-rose-400 focus:outline-none transition-colors"
              dir="rtl"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim()}
              className="w-11 h-11 rounded-xl bg-gradient-to-r from-rose-500 to-rose-600 text-white flex items-center justify-center hover:from-rose-400 hover:to-rose-500 transition-all disabled:opacity-40 disabled:cursor-not-allowed active:scale-95 flex-shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
