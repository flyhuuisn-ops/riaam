import { useState, useRef, useEffect } from 'react';
import { Lock, Calendar, Mail, Heart, AlertCircle, ArrowRight, KeyRound } from 'lucide-react';
import { SECURITY_QUESTIONS } from '@/lib/constants';

type QuestionKey = 'date' | 'email' | 'nickname';

interface AuthScreenProps {
  onSuccess: () => void;
}

export default function AuthScreen({ onSuccess }: AuthScreenProps) {
  const [activeQuestion, setActiveQuestion] = useState<QuestionKey>('date');
  const [error, setError] = useState(false);
  const [showBackup, setShowBackup] = useState(false);

  // date fields
  const [year, setYear] = useState('');
  const [month, setMonth] = useState('');
  const [day, setDay] = useState('');

  // email / nickname
  const [textAnswer, setTextAnswer] = useState('');

  const yearRef = useRef<HTMLInputElement>(null);
  const monthRef = useRef<HTMLInputElement>(null);
  const dayRef = useRef<HTMLInputElement>(null);
  const textRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (activeQuestion === 'date') {
      setTimeout(() => yearRef.current?.focus(), 100);
    } else {
      setTimeout(() => textRef.current?.focus(), 100);
    }
  }, [activeQuestion, showBackup]);

  const normalize = (s: string) => s.trim().toLowerCase().replace(/\s+/g, '');

  const checkDate = (): boolean => {
    const y = year.trim();
    const m = month.trim().replace(/^0+/, '');
    const d = day.trim().replace(/^0+/, '');
    const formatted1 = `${y}/${m.padStart(2, '0')}/${d.padStart(2, '0')}`;
    const formatted2 = `${y}/${m}/${d}`;
    const answers = SECURITY_QUESTIONS.date.answers.map(normalize);
    return answers.includes(normalize(formatted1)) || answers.includes(normalize(formatted2));
  };

  const checkText = (): boolean => {
    const answers = SECURITY_QUESTIONS[activeQuestion].answers.map(normalize);
    return answers.includes(normalize(textAnswer));
  };

  const handleVerify = () => {
    const ok = activeQuestion === 'date' ? checkDate() : checkText();
    if (ok) {
      setError(false);
      onSuccess();
    } else {
      setError(true);
      setTimeout(() => setError(false), 3000);
    }
  };

  const handleDateKey = (
    e: React.KeyboardEvent<HTMLInputElement>,
    max: number,
    nextRef?: React.RefObject<HTMLInputElement | null>
  ) => {
    if (e.key === 'Enter') {
      if (nextRef) nextRef.current?.focus();
      else handleVerify();
    }
  };

  const switchToBackup = () => {
    setShowBackup(true);
    setActiveQuestion('email');
    setTextAnswer('');
    setError(false);
  };

  const renderDateInputs = () => (
    <div className="flex items-center justify-center gap-2" dir="ltr">
      <div className="flex flex-col items-center gap-1">
        <label className="text-xs text-gray-400 mb-0.5">YYYY</label>
        <input
          ref={yearRef}
          type="text"
          inputMode="numeric"
          maxLength={4}
          value={year}
          onChange={(e) => setYear(e.target.value.replace(/\D/g, ''))}
          onKeyDown={(e) => handleDateKey(e, 4, monthRef)}
          placeholder="YYYY"
          className="w-20 h-14 text-center text-lg bg-night-850 border border-night-600 rounded-xl text-white placeholder-gray-600 focus:border-rose-400 focus:outline-none transition-colors"
        />
      </div>
      <span className="text-gray-500 text-xl mt-6">/</span>
      <div className="flex flex-col items-center gap-1">
        <label className="text-xs text-gray-400 mb-0.5">MM</label>
        <input
          ref={monthRef}
          type="text"
          inputMode="numeric"
          maxLength={2}
          value={month}
          onChange={(e) => setMonth(e.target.value.replace(/\D/g, ''))}
          onKeyDown={(e) => handleDateKey(e, 2, dayRef)}
          placeholder="MM"
          className="w-16 h-14 text-center text-lg bg-night-850 border border-night-600 rounded-xl text-white placeholder-gray-600 focus:border-rose-400 focus:outline-none transition-colors"
        />
      </div>
      <span className="text-gray-500 text-xl mt-6">/</span>
      <div className="flex flex-col items-center gap-1">
        <label className="text-xs text-gray-400 mb-0.5">DD</label>
        <input
          ref={dayRef}
          type="text"
          inputMode="numeric"
          maxLength={2}
          value={day}
          onChange={(e) => setDay(e.target.value.replace(/\D/g, ''))}
          onKeyDown={(e) => handleDateKey(e, 2)}
          placeholder="DD"
          className="w-16 h-14 text-center text-lg bg-night-850 border border-night-600 rounded-xl text-white placeholder-gray-600 focus:border-rose-400 focus:outline-none transition-colors"
        />
      </div>
    </div>
  );

  const renderTextInput = () => (
    <input
      ref={textRef}
      type="text"
      value={textAnswer}
      onChange={(e) => setTextAnswer(e.target.value)}
      onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
      placeholder="اكتب إجابتك هنا"
      className="w-full h-14 px-5 text-lg bg-night-850 border border-night-600 rounded-xl text-white placeholder-gray-600 focus:border-rose-400 focus:outline-none transition-colors"
      dir="rtl"
    />
  );

  const currentIcon = activeQuestion === 'date' ? Calendar : activeQuestion === 'email' ? Mail : Heart;
  const Icon = currentIcon;

  return (
    <div className="min-h-screen bg-night-950 flex items-center justify-center p-4 relative overflow-hidden">
      {/* ambient glow */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-rose-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-rose-700/5 rounded-full blur-3xl" />

      <div className="relative z-10 w-full max-w-md animate-slide-up">
        <div className="glass-card rounded-3xl p-8 shadow-2xl">
          {/* header */}
          <div className="flex flex-col items-center mb-7">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-rose-500/20 to-rose-700/10 flex items-center justify-center mb-4 border border-rose-500/20">
              {showBackup ? <KeyRound className="w-7 h-7 text-rose-300" /> : <Lock className="w-7 h-7 text-rose-300" />}
            </div>
            <h1 className="text-2xl font-bold text-white text-center">
              {showBackup ? 'الأسئلة الاحتياطية' : 'أدخل تاريخ لقائنا للدخول'}
            </h1>
            {showBackup && (
              <p className="text-sm text-gray-400 mt-2 text-center">الإجابة عن سؤال واحد تكفي</p>
            )}
          </div>

          {/* question selector (backup mode) */}
          {showBackup && (
            <div className="flex gap-2 mb-6">
              {(['email', 'nickname'] as QuestionKey[]).map((q) => {
                const QIcon = q === 'email' ? Mail : Heart;
                return (
                  <button
                    key={q}
                    onClick={() => {
                      setActiveQuestion(q);
                      setTextAnswer('');
                      setError(false);
                    }}
                    className={`flex-1 flex items-center justify-center gap-2 py-3 px-3 rounded-xl text-sm font-medium transition-all ${
                      activeQuestion === q
                        ? 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                        : 'bg-night-850 text-gray-400 border border-night-600 hover:border-night-500'
                    }`}
                  >
                    <QIcon className="w-4 h-4" />
                    {SECURITY_QUESTIONS[q].title}
                  </button>
                );
              })}
            </div>
          )}

          {/* current question label */}
          {!showBackup && (
            <div className="flex items-center gap-2 mb-5 text-rose-300">
              <Icon className="w-5 h-5" />
              <span className="text-sm font-medium">{SECURITY_QUESTIONS.date.title}</span>
            </div>
          )}

          {/* input area */}
          <div className="mb-5">
            {activeQuestion === 'date' && !showBackup ? renderDateInputs() : renderTextInput()}
          </div>

          {/* error message */}
          {error && (
            <div className="flex items-center justify-center gap-2 mb-5 text-rose-400 text-sm animate-fade-in">
              <AlertCircle className="w-4 h-4" />
              <span>عذراً، الإجابة خاطئة</span>
            </div>
          )}

          {/* verify button */}
          <button
            onClick={handleVerify}
            className="w-full h-14 bg-gradient-to-r from-rose-500 to-rose-600 text-white font-bold text-lg rounded-xl hover:from-rose-400 hover:to-rose-500 transition-all shadow-lg shadow-rose-500/20 active:scale-[0.98]"
          >
            تحقق
          </button>

          {/* forgot date link */}
          {!showBackup && (
            <button
              onClick={switchToBackup}
              className="w-full mt-4 text-gray-400 hover:text-rose-300 text-sm flex items-center justify-center gap-1 transition-colors"
            >
              <ArrowRight className="w-4 h-4 rotate-180" />
              نسيت التاريخ
            </button>
          )}
        </div>

        <p className="text-center text-gray-600 text-xs mt-6">
          صفحة خاصة وآمنة — مخصصة لشخص واحد
        </p>
      </div>
    </div>
  );
}
