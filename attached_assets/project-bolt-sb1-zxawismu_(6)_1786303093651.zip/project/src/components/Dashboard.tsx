import { useState, useEffect, useRef } from 'react';
import { DoorOpen, BookOpen, MessageCircle, Info, HelpCircle, ChevronDown, LogIn } from 'lucide-react';
import { PERSONAL_MESSAGE } from '@/lib/constants';
import { type AppUser } from '@/lib/auth';

interface DashboardProps {
  user: AppUser | null;
  onPanic: () => void;
  onDisguise: () => void;
  onOpenChat: () => void;
  onOpenAuth: () => void;
  onOpenSettings: () => void;
  children: React.ReactNode;
}

const PANIC_TIP_TEXT =
  'هذا زر الطوارئ؛ للتحويل لصفحة تعليم اللغة الإنجليزية وحذف جميع الرسائل.';
const DISGUISE_TIP_TEXT =
  'هذا زر التمويه؛ للتحويل لصفحة تعليم اللغة الإنجليزية دون حذف الرسائل.';

const PANIC_DONT_REPEAT_KEY = 'tip_panic_dismissed_forever';
const DISGUISE_DONT_REPEAT_KEY = 'tip_disguise_dismissed_forever';

export default function Dashboard({
  user,
  onPanic,
  onDisguise,
  onOpenChat,
  onOpenAuth,
  onOpenSettings,
  children,
}: DashboardProps) {
  const [showPanicTip, setShowPanicTip] = useState(false);
  const [showDisguiseTip, setShowDisguiseTip] = useState(false);
  const [showPanicHelp, setShowPanicHelp] = useState(false);
  const [showDisguiseHelp, setShowDisguiseHelp] = useState(false);

  const panicTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const disguiseTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!localStorage.getItem(PANIC_DONT_REPEAT_KEY)) {
      setShowPanicTip(true);
    }
    if (!localStorage.getItem(DISGUISE_DONT_REPEAT_KEY)) {
      setShowDisguiseTip(true);
    }
  }, []);

  useEffect(() => {
    if (showPanicTip) {
      panicTimerRef.current = setTimeout(() => setShowPanicTip(false), 20000);
      return () => {
        if (panicTimerRef.current) clearTimeout(panicTimerRef.current);
      };
    }
  }, [showPanicTip]);

  useEffect(() => {
    if (showDisguiseTip) {
      disguiseTimerRef.current = setTimeout(() => setShowDisguiseTip(false), 20000);
      return () => {
        if (disguiseTimerRef.current) clearTimeout(disguiseTimerRef.current);
      };
    }
  }, [showDisguiseTip]);

  const dismissPanicTip = () => {
    setShowPanicTip(false);
    if (panicTimerRef.current) clearTimeout(panicTimerRef.current);
  };

  const dismissPanicForever = () => {
    localStorage.setItem(PANIC_DONT_REPEAT_KEY, '1');
    dismissPanicTip();
  };

  const dismissDisguiseTip = () => {
    setShowDisguiseTip(false);
    if (disguiseTimerRef.current) clearTimeout(disguiseTimerRef.current);
  };

  const dismissDisguiseForever = () => {
    localStorage.setItem(DISGUISE_DONT_REPEAT_KEY, '1');
    dismissDisguiseTip();
  };

  return (
    <div className="min-h-screen bg-night-950 relative overflow-hidden">
      {/* ambient glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-rose-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-rose-700/5 rounded-full blur-3xl pointer-events-none" />

      {/* top bar */}
      <header className="relative z-20 border-b border-night-700/50 bg-night-900/80 backdrop-blur-xl sticky top-0">
        <div className="max-w-5xl mx-auto px-3 sm:px-6 py-3 flex items-center justify-between gap-3 sm:gap-4 flex-wrap">
          {/* left: auth/user button + chat button */}
          <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
            {user ? (
              <button
                onClick={onOpenSettings}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-rose-500/15 text-rose-300 hover:bg-rose-500/25 transition-colors text-sm font-medium border border-rose-500/20 max-w-[160px] truncate"
                title={user.display_name}
              >
                <span className="truncate">{user.display_name}</span>
                <ChevronDown className="w-3.5 h-3.5 flex-shrink-0" />
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-rose-500/15 text-rose-300 hover:bg-rose-500/25 transition-colors text-sm font-medium border border-rose-500/20"
              >
                <LogIn className="w-4 h-4" />
                <span>تسجيل دخول</span>
              </button>
            )}
            <button
              onClick={onOpenChat}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-rose-500/15 text-rose-300 hover:bg-rose-500/25 transition-colors text-sm font-medium border border-rose-500/20"
            >
              <MessageCircle className="w-4 h-4" />
              <span className="hidden sm:inline">مراسلة</span>
            </button>
          </div>

          {/* right: security buttons with help icons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* disguise button + help */}
            <div className="relative flex items-center gap-1">
              <button
                onClick={onDisguise}
                title="تمويه سريع (F3)"
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-blue-500/15 border border-blue-400/40 hover:bg-blue-500/30 hover:border-blue-400 flex items-center justify-center transition-all group"
              >
                <BookOpen className="w-5 h-5 text-blue-300 group-hover:text-blue-200 transition-colors" />
              </button>
              <button
                onClick={() => {
                  setShowDisguiseHelp((v) => !v);
                  setShowPanicHelp(false);
                }}
                className="w-6 h-6 rounded-full bg-night-700 border border-night-600 hover:border-blue-400/50 flex items-center justify-center transition-colors"
                title="ما هذا الزر؟"
              >
                <HelpCircle className="w-3.5 h-3.5 text-gray-400 hover:text-blue-300 transition-colors" />
              </button>

              {/* disguise tip - bottom positioned */}
              {showDisguiseTip && (
                <div className="absolute top-full mt-2 left-0 w-64 p-3 rounded-xl bg-night-800 border border-blue-400/30 text-xs text-gray-300 animate-fade-in shadow-xl z-30">
                  <div className="flex items-start gap-2 mb-3">
                    <Info className="w-4 h-4 text-blue-300 flex-shrink-0 mt-0.5" />
                    <span>{DISGUISE_TIP_TEXT}</span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={dismissDisguiseTip}
                      className="flex-1 py-1.5 px-2 rounded-lg bg-night-700 hover:bg-night-600 text-gray-200 text-xs font-medium transition-colors"
                    >
                      فهمت
                    </button>
                    <button
                      onClick={dismissDisguiseForever}
                      className="flex-1 py-1.5 px-2 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-200 text-xs font-medium transition-colors border border-blue-400/20"
                    >
                      فهمت، لا تُكرر
                    </button>
                  </div>
                </div>
              )}

              {/* disguise help popover - bottom positioned */}
              {showDisguiseHelp && (
                <div className="absolute top-full mt-2 left-0 w-48 p-3 rounded-xl bg-night-800 border border-blue-400/30 text-xs text-gray-300 animate-fade-in shadow-xl z-30">
                  <div className="flex items-center gap-2">
                    <kbd className="px-2 py-1 rounded bg-night-700 border border-night-600 text-blue-300 font-mono text-xs">F3</kbd>
                    <span>مفتاح اختصار زر التمويه</span>
                  </div>
                </div>
              )}
            </div>

            {/* panic button + help */}
            <div className="relative flex items-center gap-1">
              <button
                onClick={onPanic}
                title="طوارئ (Esc)"
                className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-amber-500/15 border border-amber-400/40 hover:bg-amber-500/30 hover:border-amber-400 flex items-center justify-center transition-all group"
              >
                <DoorOpen className="w-5 h-5 text-amber-300 group-hover:text-amber-200 transition-colors" />
              </button>
              <button
                onClick={() => {
                  setShowPanicHelp((v) => !v);
                  setShowDisguiseHelp(false);
                }}
                className="w-6 h-6 rounded-full bg-night-700 border border-night-600 hover:border-amber-400/50 flex items-center justify-center transition-colors"
                title="ما هذا الزر؟"
              >
                <HelpCircle className="w-3.5 h-3.5 text-gray-400 hover:text-amber-300 transition-colors" />
              </button>

              {/* panic tip - bottom positioned */}
              {showPanicTip && (
                <div className="absolute top-full mt-2 right-0 w-72 p-3 rounded-xl bg-night-800 border border-amber-400/30 text-xs text-gray-300 animate-fade-in shadow-xl z-30">
                  <div className="flex items-start gap-2 mb-3">
                    <Info className="w-4 h-4 text-amber-300 flex-shrink-0 mt-0.5" />
                    <span>{PANIC_TIP_TEXT}</span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={dismissPanicTip}
                      className="flex-1 py-1.5 px-2 rounded-lg bg-night-700 hover:bg-night-600 text-gray-200 text-xs font-medium transition-colors"
                    >
                      فهمت
                    </button>
                    <button
                      onClick={dismissPanicForever}
                      className="flex-1 py-1.5 px-2 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 text-xs font-medium transition-colors border border-amber-400/20"
                    >
                      فهمت، لا تُكرر
                    </button>
                  </div>
                </div>
              )}

              {/* panic help popover - bottom positioned */}
              {showPanicHelp && (
                <div className="absolute top-full mt-2 right-0 w-48 p-3 rounded-xl bg-night-800 border border-amber-400/30 text-xs text-gray-300 animate-fade-in shadow-xl z-30">
                  <div className="flex items-center gap-2">
                    <kbd className="px-2 py-1 rounded bg-night-700 border border-night-600 text-amber-300 font-mono text-xs">Esc</kbd>
                    <span>مفتاح اختصار زر الطوارئ</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* personal message */}
      <main className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="glass-card rounded-3xl p-6 sm:p-10 animate-fade-in">
          <div className="flex items-center gap-2 mb-6">
            <span className="text-xl font-bold text-rose-300">رسالة إليكِ</span>
          </div>
          <div className="text-gray-200 message-line-height text-base sm:text-lg whitespace-pre-wrap leading-loose">
            {PERSONAL_MESSAGE}
          </div>
          <div className="mt-8 pt-6 border-t border-night-700/50 flex items-center justify-center gap-2 text-gray-500 text-sm">
            <span>اضغطي على زر "مراسلة" في الأعلى للتواصل</span>
          </div>
        </div>
      </main>

      {/* chat window (rendered as children) */}
      {children}
    </div>
  );
}
