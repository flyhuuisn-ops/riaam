import { useState } from 'react';
import { X, UserPlus, LogIn, AlertCircle, Loader2 } from 'lucide-react';
import { createUser, loginUser, type AppUser } from '@/lib/auth';

interface AuthModalProps {
  onClose: () => void;
  onSuccess: (user: AppUser, isNew: boolean) => void;
}

export default function AuthModal({ onClose, onSuccess }: AuthModalProps) {
  const [mode, setMode] = useState<'signup' | 'login'>('signup');
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const validateUsername = (u: string): boolean => {
    return /^[a-z0-9._]+$/.test(u);
  };

  const handleSubmit = async () => {
    setError('');
    const name = displayName.trim();
    const handle = username.trim().toLowerCase();

    if (!name || !handle) {
      setError('يرجى ملء جميع الحقول');
      return;
    }

    if (!validateUsername(handle)) {
      setError('اليوزر يجب أن يحتوي على أحرف إنجليزية أو أرقام أو نقاط أو _ فقط');
      return;
    }

    setLoading(true);
    try {
      if (mode === 'signup') {
        const { user, error: err } = await createUser(name, handle);
        if (err || !user) {
          setError(err || 'حدث خطأ أثناء إنشاء الحساب');
        } else {
          onSuccess(user, true);
        }
      } else {
        const { user, error: err } = await loginUser(name, handle);
        if (err || !user) {
          setError(err || 'حدث خطأ أثناء تسجيل الدخول');
        } else {
          onSuccess(user, false);
        }
      }
    } catch {
      setError('حدث خطأ غير متوقع');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 animate-fade-in"
        onClick={onClose}
      />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md p-6 bg-night-900 border border-night-600 rounded-2xl shadow-2xl animate-slide-up">
        {/* header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-white">
            {mode === 'signup' ? 'إنشاء حساب جديد' : 'تسجيل الدخول'}
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-night-700 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* mode tabs */}
        <div className="flex gap-2 mb-5 p-1 bg-night-850 rounded-xl">
          <button
            onClick={() => { setMode('signup'); setError(''); }}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
              mode === 'signup'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            إنشاء حساب
          </button>
          <button
            onClick={() => { setMode('login'); setError(''); }}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all ${
              mode === 'login'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                : 'text-gray-400 hover:text-gray-200'
            }`}
          >
            <LogIn className="w-4 h-4" />
            تسجيل دخول
          </button>
        </div>

        {/* fields */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1.5">اسم المستخدم</label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="الاسم الظاهر (عربي أو إنجليزي)"
              className="w-full h-12 px-4 bg-night-850 border border-night-600 rounded-xl text-white placeholder-gray-600 focus:border-rose-400 focus:outline-none transition-colors"
              dir="rtl"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1.5">اليوزر</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="english_chars.123_"
              className="w-full h-12 px-4 bg-night-850 border border-night-600 rounded-xl text-white placeholder-gray-600 focus:border-rose-400 focus:outline-none transition-colors font-mono"
              dir="ltr"
            />
            <p className="text-xs text-gray-600 mt-1.5">أحرف إنجليزية، أرقام، نقاط، و _ فقط</p>
          </div>
        </div>

        {/* error */}
        {error && (
          <div className="flex items-start gap-2 mt-4 p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-300 text-sm animate-fade-in">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* submit */}
        <button
          onClick={handleSubmit}
          disabled={loading}
          className="w-full h-12 mt-5 bg-gradient-to-r from-rose-500 to-rose-600 text-white font-bold rounded-xl hover:from-rose-400 hover:to-rose-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98] flex items-center justify-center gap-2"
        >
          {loading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              جاري المعالجة...
            </>
          ) : mode === 'signup' ? (
            'إنشاء الحساب'
          ) : (
            'تسجيل الدخول'
          )}
        </button>
      </div>
    </>
  );
}
