import { useState, useEffect, useCallback } from 'react';
import { supabase } from './supabase';

export interface AppUser {
  id: string;
  display_name: string;
  username: string;
}

const STORAGE_KEY = 'app_user_session';

export function useUserSession() {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed: AppUser = JSON.parse(stored);
        setUser(parsed);
      }
    } catch {
      // ignore parse errors
    }
    setLoading(false);
  }, []);

  const saveSession = useCallback((u: AppUser) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(u));
    setUser(u);
  }, []);

  const clearSession = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setUser(null);
  }, []);

  return { user, loading, saveSession, clearSession, setUser };
}

export async function checkUsernameExists(username: string): Promise<boolean> {
  const normalized = username.toLowerCase().trim();
  const { data, error } = await supabase
    .from('users')
    .select('id')
    .eq('username', normalized)
    .maybeSingle();

  if (error) {
    console.error('Error checking username:', error);
    return false;
  }
  return data !== null;
}

export async function createUser(
  displayName: string,
  username: string
): Promise<{ user: AppUser | null; error: string | null }> {
  const normalized = username.toLowerCase().trim();
  const exists = await checkUsernameExists(normalized);
  if (exists) {
    return {
      user: null,
      error: 'هذا اليوزر مُستخدم، قومي بكتابة يوزر جديد أو انتقلي الى قسم تسجيل الدخول',
    };
  }

  const { data, error } = await supabase
    .from('users')
    .insert({
      display_name: displayName.trim() || normalized,
      username: normalized,
    })
    .select()
    .single();

  if (error) {
    return { user: null, error: error.message };
  }

  return { user: data as AppUser, error: null };
}

export async function loginUser(
  displayName: string,
  username: string
): Promise<{ user: AppUser | null; error: string | null }> {
  const normalized = username.toLowerCase().trim();
  const exists = await checkUsernameExists(normalized);
  if (!exists) {
    return {
      user: null,
      error: 'هذا اليوزر غير مُستخدم قومي بكتابة يوزر مُستخدم أو انتقلي الى قسم إنشاء حساب',
    };
  }

  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('username', normalized)
    .maybeSingle();

  if (error || !data) {
    return { user: null, error: 'تعذر العثور على الحساب' };
  }

  // Update display name if a new one was provided
  const newName = displayName.trim();
  if (newName && data.display_name !== newName) {
    const { data: updated } = await supabase
      .from('users')
      .update({ display_name: newName })
      .eq('id', data.id)
      .select('*')
      .single();
    if (updated) {
      return { user: updated as AppUser, error: null };
    }
  }

  return { user: data as AppUser, error: null };
}

export async function updateUserProfile(
  userId: string,
  currentHandle: string,
  newDisplayName: string,
  newHandle: string
): Promise<{ user: AppUser | null; error: string | null }> {
  const normalizedNew = newHandle.toLowerCase().trim();
  const newName = newDisplayName.trim();

  // If handle is changing, check the new one isn't taken
  if (normalizedNew !== currentHandle) {
    const exists = await checkUsernameExists(normalizedNew);
    if (exists) {
      return { user: null, error: 'هذا اليوزر مُستخدم بالفعل' };
    }
  }

  // Update user row
  const { data, error } = await supabase
    .from('users')
    .update({ display_name: newName || normalizedNew, username: normalizedNew })
    .eq('id', userId)
    .select('*')
    .single();

  if (error) {
    return { user: null, error: error.message };
  }

  // Update messages' sender_handle and sender_display_name (preserve all messages)
  if (normalizedNew !== currentHandle) {
    const { error: msgHandleError } = await supabase
      .from('messages')
      .update({ sender_handle: normalizedNew })
      .eq('sender_handle', currentHandle);

    if (msgHandleError) {
      console.error('Failed to update messages sender_handle:', msgHandleError);
    }
  }

  if (newName) {
    const { error: msgNameError } = await supabase
      .from('messages')
      .update({ sender_display_name: newName })
      .eq('sender_handle', normalizedNew);

    if (msgNameError) {
      console.error('Failed to update messages sender_display_name:', msgNameError);
    }
  }

  return { user: data as AppUser, error: null };
}

export async function deleteUserAccount(
  userId: string,
  handle: string
): Promise<{ success: boolean; error: string | null }> {
  // Delete all messages sent by this user
  const { error: msgError } = await supabase
    .from('messages')
    .delete()
    .eq('sender_handle', handle);
  if (msgError) {
    console.error('Failed to delete messages:', msgError);
  }

  // Delete the user account
  const { error: userError } = await supabase
    .from('users')
    .delete()
    .eq('id', userId);
  if (userError) {
    return { success: false, error: userError.message };
  }

  return { success: true, error: null };
}
