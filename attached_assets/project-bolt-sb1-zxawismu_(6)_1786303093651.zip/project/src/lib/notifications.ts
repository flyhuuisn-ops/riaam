import { supabase } from './supabase';

export type ActivityEvent =
  | 'login'
  | 'logout'
  | 'panic'
  | 'disguise'
  | 'message';

export interface ActivityPayload {
  eventType: ActivityEvent;
  deviceInfo?: string;
  durationSeconds?: number;
  username?: string;
}

export function getDeviceInfo(): string {
  const ua = navigator.userAgent;
  const platform = navigator.platform || 'unknown';
  const lang = navigator.language || 'unknown';
  const screen = `${window.screen.width}x${window.screen.height}`;
  return `UA: ${ua} | Platform: ${platform} | Lang: ${lang} | Screen: ${screen}`;
}

export async function logActivity(payload: ActivityPayload): Promise<void> {
  try {
    await supabase.from('activity_log').insert({
      event_type: payload.eventType,
      device_info: payload.deviceInfo ?? getDeviceInfo(),
      duration_seconds: payload.durationSeconds ?? null,
      username: payload.username ?? null,
    });
  } catch (err) {
    console.error('Failed to log activity:', err);
  }
}

export interface NotificationExtra {
  durationSeconds?: number;
  messagePreview?: string;
  handle?: string;
  displayName?: string;
}

export async function sendNotification(
  eventType: ActivityEvent,
  extra?: NotificationExtra
): Promise<void> {
  const deviceInfo = getDeviceInfo();
  const now = new Date();
  const timeStr = now.toLocaleString('ar-EG', {
    timeZone: 'Asia/Baghdad',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const titles: Record<ActivityEvent, string> = {
    login: '🔔 إشعار دخول إلى الصفحة السرية',
    logout: '🔔 إشعار خروج من الصفحة السرية',
    panic: '🚨 إشعار طوارئ - تم تفعيل زر الطوارئ',
    disguise: '🪄 إشعار تمويه سريع - تم تفعيل زر التمويه',
    message: '💬 رسالة جديدة في الصفحة السرية',
  };

  const lines: string[] = [titles[eventType]];

  if (extra?.handle) {
    lines.push(`اليوزر: ${extra.handle}`);
  }
  if (extra?.displayName) {
    lines.push(`الاسم: ${extra.displayName}`);
  }

  lines.push(`الزمن: ${timeStr}`);
  lines.push(`الجهاز: ${deviceInfo}`);

  if (extra?.durationSeconds !== undefined) {
    const mins = Math.floor(extra.durationSeconds / 60);
    const secs = extra.durationSeconds % 60;
    lines.push(`مدة البقاء: ${mins} دقيقة و ${secs} ثانية`);
  }

  if (extra?.messagePreview) {
    lines.push(`معاينة الرسالة: ${extra.messagePreview.slice(0, 200)}`);
  }

  const body = lines.join('\n');

  await logActivity({
    eventType,
    deviceInfo,
    durationSeconds: extra?.durationSeconds,
    username: extra?.handle,
  });

  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/notify`;
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({
        eventType,
        subject: titles[eventType],
        body,
        handle: extra?.handle,
        displayName: extra?.displayName,
        deviceInfo,
        durationSeconds: extra?.durationSeconds,
        messagePreview: extra?.messagePreview,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Notification edge function returned error:', response.status, errorText);
    }
  } catch (err) {
    console.error('Notification edge function failed:', err);
  }
}
