import { useState, useEffect, useRef, useCallback } from 'react';
import Dashboard from '@/components/Dashboard';
import ChatWindow from '@/components/ChatWindow';
import EnglishDisguise from '@/components/EnglishDisguise';
import AuthModal from '@/components/AuthModal';
import UserSettingsModal from '@/components/UserSettingsModal';
import { sendNotification, getDeviceInfo } from '@/lib/notifications';
import { useUserSession, type AppUser } from '@/lib/auth';

type AppState = 'dashboard' | 'disguise';

export default function App() {
  const { user, loading, saveSession, clearSession, setUser } = useUserSession();
  const [appState, setAppState] = useState<AppState>('dashboard');
  const [chatOpen, setChatOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [settingsModalOpen, setSettingsModalOpen] = useState(false);
  const loginTimeRef = useRef<number | null>(null);
  const disguisedRef = useRef(false);

  useEffect(() => {
    if (user && !loginTimeRef.current) {
      loginTimeRef.current = Date.now();
    }
  }, [user]);

  const handleAuthSuccess = useCallback(
    async (u: AppUser) => {
      saveSession(u);
      loginTimeRef.current = Date.now();
      setAppState('dashboard');
      setAuthModalOpen(false);
      await sendNotification('login', {
        handle: u.username,
        displayName: u.display_name,
      });
    },
    [saveSession]
  );

  const handlePanic = useCallback(() => {
    if (disguisedRef.current) return;
    disguisedRef.current = true;

    setChatOpen(false);
    setSettingsModalOpen(false);
    setAuthModalOpen(false);
    setAppState('disguise');

    const handle = user?.username;
    const name = user?.display_name;
    (async () => {
      await sendNotification('panic', { handle, displayName: name });
    })();

    try {
      const googleUrl = 'https://www.google.com/search?q=learn+english+online';
      history.replaceState(null, '', googleUrl);
      const fakePaths = [
        'https://www.google.com/search?q=english+grammar',
        'https://www.google.com/search?q=english+vocabulary',
        'https://www.google.com/search?q=english+learning+websites',
        'https://www.google.com/search?q=youglish',
        'https://www.google.com/search?q=langeek',
      ];
      fakePaths.forEach((path) => {
        history.pushState(null, '', path);
      });
    } catch (err) {
      console.error('History manipulation failed:', err);
    }
  }, [user]);

  const handleDisguise = useCallback(() => {
    if (disguisedRef.current) return;
    disguisedRef.current = true;

    setChatOpen(false);
    setSettingsModalOpen(false);
    setAuthModalOpen(false);
    setAppState('disguise');

    const handle = user?.username;
    const name = user?.display_name;
    (async () => {
      await sendNotification('disguise', { handle, displayName: name });
    })();

    try {
      const googleUrl = 'https://www.google.com/search?q=learn+english';
      history.replaceState(null, '', googleUrl);
    } catch (err) {
      console.error('History manipulation failed:', err);
    }
  }, [user]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (appState !== 'dashboard') return;

      if (e.key === 'Escape') {
        e.preventDefault();
        handlePanic();
      } else if (e.key === 'F3') {
        e.preventDefault();
        handleDisguise();
      }
    };

    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [appState, handlePanic, handleDisguise]);

  useEffect(() => {
    const handleUnload = () => {
      if (appState === 'dashboard' && loginTimeRef.current && user) {
        const duration = Math.floor((Date.now() - loginTimeRef.current) / 1000);
        const subject = '🔔 إشعار خروج من الصفحة السرية';
        const deviceInfo = getDeviceInfo();
        const now = new Date();
        const timeStr = now.toLocaleString('ar-EG', {
          timeZone: 'Asia/Baghdad',
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        });
        const body = [
          subject,
          `اليوزر: ${user.username}`,
          `الاسم: ${user.display_name}`,
          `الزمن: ${timeStr}`,
          `الجهاز: ${deviceInfo}`,
          `مدة البقاء: ${Math.floor(duration / 60)} دقيقة و ${duration % 60} ثانية`,
        ].join('\n');

        try {
          fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/notify`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            },
            body: JSON.stringify({
              eventType: 'logout',
              subject,
              body,
              handle: user.username,
              displayName: user.display_name,
              deviceInfo,
              durationSeconds: duration,
            }),
            keepalive: true,
          });
        } catch {
          // best effort
        }
      }
    };

    window.addEventListener('beforeunload', handleUnload);
    return () => window.removeEventListener('beforeunload', handleUnload);
  }, [appState, user]);

  const handleProfileUpdate = (updatedUser: AppUser) => {
    saveSession(updatedUser);
    setSettingsModalOpen(false);
  };

  const handleUserDelete = () => {
    clearSession();
    setSettingsModalOpen(false);
    setChatOpen(false);
    disguisedRef.current = false;
    loginTimeRef.current = null;
  };

  const handleOpenChat = () => {
    if (!user) {
      setAuthModalOpen(true);
    } else {
      setChatOpen(true);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-night-950 flex items-center justify-center">
        <div className="text-gray-500 text-sm">جاري التحميل...</div>
      </div>
    );
  }

  if (appState === 'disguise') {
    return <EnglishDisguise />;
  }

  return (
    <>
      <Dashboard
        user={user}
        onPanic={handlePanic}
        onDisguise={handleDisguise}
        onOpenChat={handleOpenChat}
        onOpenAuth={() => setAuthModalOpen(true)}
        onOpenSettings={() => setSettingsModalOpen(true)}
      >
        {chatOpen && user && (
          <ChatWindow
            user={user}
            onClose={() => setChatOpen(false)}
            onPanic={handlePanic}
            onDisguise={handleDisguise}
          />
        )}
      </Dashboard>

      {authModalOpen && (
        <AuthModal
          onClose={() => setAuthModalOpen(false)}
          onSuccess={handleAuthSuccess}
        />
      )}

      {settingsModalOpen && user && (
        <UserSettingsModal
          user={user}
          onUpdate={handleProfileUpdate}
          onDelete={handleUserDelete}
          onClose={() => setSettingsModalOpen(false)}
        />
      )}
    </>
  );
}
