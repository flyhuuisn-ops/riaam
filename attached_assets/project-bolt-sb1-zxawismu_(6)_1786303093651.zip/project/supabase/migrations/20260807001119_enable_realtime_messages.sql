-- Enable real-time on messages table
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
