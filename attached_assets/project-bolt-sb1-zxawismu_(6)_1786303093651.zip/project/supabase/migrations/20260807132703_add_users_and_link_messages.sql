/*
# Add users table and link messages to usernames

1. New Tables
- `users` - user accounts with display name and unique username handle
  - id (uuid, primary key)
  - display_name (text, not null) - visible name, changeable anytime, accepts Arabic/English
  - username (text, unique, not null) - handle, English chars/numbers/dots/underscores only
  - created_at (timestamptz, default now())

2. Modified Tables
- `messages` - add `username` column to link messages to user accounts
  - username (text, nullable) - links message to user account for recovery
- `activity_log` - add `username` column for tracking which user triggered events

3. Security
- Enable RLS on `users`.
- Allow anon + authenticated CRUD (single-tenant app, no Supabase auth).
- Messages and activity_log keep existing policies, new column is accessible.

4. Important Notes
- This is a single-tenant app with no Supabase auth; access is gated by secret questions in the UI.
- Multiple usernames can be created (if one is forgotten, a new one can be made).
- Messages are linked to username for recovery across devices/browser clears.
- Editing a username updates the messages.username field too (no data loss).
- Deleting a username deletes all associated messages.
*/

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  display_name text NOT NULL,
  username text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_users" ON users;
CREATE POLICY "anon_select_users" ON users FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_users" ON users;
CREATE POLICY "anon_insert_users" ON users FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_users" ON users;
CREATE POLICY "anon_update_users" ON users FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_users" ON users;
CREATE POLICY "anon_delete_users" ON users FOR DELETE
  TO anon, authenticated USING (true);

-- Add username column to messages
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'messages' AND column_name = 'username') THEN
    ALTER TABLE messages ADD COLUMN username text;
  END IF;
END $$;

-- Add username column to activity_log
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'activity_log' AND column_name = 'username') THEN
    ALTER TABLE activity_log ADD COLUMN username text;
  END IF;
END $$;

-- Drop old sender check constraint to allow any sender value
ALTER TABLE messages DROP CONSTRAINT IF EXISTS messages_sender_check;

-- Add index for username-based queries
CREATE INDEX IF NOT EXISTS idx_messages_username ON messages (username);
