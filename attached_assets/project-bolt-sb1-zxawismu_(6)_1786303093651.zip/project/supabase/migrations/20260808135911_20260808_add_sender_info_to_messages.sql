/*
# Add sender handle and display name to messages

1. Modified Tables
- `messages`
  - Add `sender_handle` (text, nullable) - the username (handle) of the user who sent the message
  - Add `sender_display_name` (text, nullable) - the display name of the user who sent the message
  - Add `is_mine` (boolean, default false) - true if the message was sent by the current logged-in user (for bubble alignment)

2. Security
- No new tables; existing RLS policies on messages remain unchanged.
- New columns are accessible via existing anon+authenticated CRUD policies.

3. Important Notes
- `sender_handle` lets us show the sender's handle on each message bubble for other participants.
- `sender_display_name` lets us show the sender's display name on each message bubble.
- `is_mine` allows WhatsApp-style bubble alignment: my messages on one side, others' on the opposite side.
- These columns are nullable so existing rows are not affected.
- An index on `sender_handle` is added for faster lookups.
*/

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'messages' AND column_name = 'sender_handle') THEN
    ALTER TABLE messages ADD COLUMN sender_handle text;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'messages' AND column_name = 'sender_display_name') THEN
    ALTER TABLE messages ADD COLUMN sender_display_name text;
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'messages' AND column_name = 'is_mine') THEN
    ALTER TABLE messages ADD COLUMN is_mine boolean NOT NULL DEFAULT false;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_messages_sender_handle ON messages (sender_handle);
