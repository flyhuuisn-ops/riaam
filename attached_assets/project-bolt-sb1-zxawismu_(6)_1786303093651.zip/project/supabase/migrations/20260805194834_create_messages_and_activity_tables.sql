/*
# Create messages and activity_log tables (single-tenant, no auth)

1. New Tables
- `messages`
  - `id` (uuid, primary key)
  - `content` (text, not null) - message text
  - `sender` (text, not null) - who sent the message ('riyam' or 'jojo')
  - `created_at` (timestamptz, default now())
- `activity_log`
  - `id` (uuid, primary key)
  - `event_type` (text, not null) - e.g. 'login', 'logout', 'panic', 'disguise', 'message'
  - `device_info` (text) - user agent / device info
  - `duration_seconds` (integer) - time spent on private page (for logout events)
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on both tables.
- Allow anon + authenticated CRUD because this is a single-tenant private app with no sign-in (access controlled by secret questions in the UI).

3. Important Notes
- This app has no Supabase auth sign-in screen; access is gated by secret questions in the frontend. Therefore policies use `TO anon, authenticated` so the anon-key client can read/write its own data.
- Messages can be bulk-deleted by the panic button (self-destruct).
*/

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content text NOT NULL,
  sender text NOT NULL CHECK (sender IN ('riyam', 'jojo')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_messages" ON messages;
CREATE POLICY "anon_select_messages" ON messages FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_messages" ON messages;
CREATE POLICY "anon_insert_messages" ON messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_messages" ON messages;
CREATE POLICY "anon_update_messages" ON messages FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_messages" ON messages;
CREATE POLICY "anon_delete_messages" ON messages FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS activity_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  device_info text,
  duration_seconds integer,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE activity_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_activity_log" ON activity_log;
CREATE POLICY "anon_select_activity_log" ON activity_log FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_activity_log" ON activity_log;
CREATE POLICY "anon_insert_activity_log" ON activity_log FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_activity_log" ON activity_log;
CREATE POLICY "anon_delete_activity_log" ON activity_log FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages (created_at);
CREATE INDEX IF NOT EXISTS idx_activity_log_created_at ON activity_log (created_at);
