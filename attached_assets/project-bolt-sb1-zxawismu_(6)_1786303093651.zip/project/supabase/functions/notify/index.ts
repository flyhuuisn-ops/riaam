import { corsHeaders } from '../_shared/cors.ts';

interface NotifyBody {
  eventType: string;
  subject: string;
  body: string;
  handle?: string;
  displayName?: string;
  deviceInfo?: string;
  durationSeconds?: number;
  messagePreview?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const payload: NotifyBody = await req.json();

    const botToken = Deno.env.get('TELEGRAM_BOT_TOKEN');
    const chatId = Deno.env.get('TELEGRAM_CHAT_ID');

    if (!botToken || !chatId) {
      console.error('Telegram secrets not configured:', {
        hasToken: !!botToken,
        hasChatId: !!chatId,
      });
      return new Response(
        JSON.stringify({ error: 'Telegram bot not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Build the Telegram message text
    const lines: string[] = [payload.subject || '🔔 إشعار'];

    if (payload.handle) {
      lines.push(`اليوزر: ${payload.handle}`);
    }
    if (payload.displayName) {
      lines.push(`الاسم: ${payload.displayName}`);
    }

    // Precise timestamp (Asia/Baghdad)
    const now = new Date();
    const timeStr = now.toLocaleString('ar-EG', {
      timeZone: 'Asia/Baghdad',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    lines.push(`الزمن: ${timeStr}`);

    // Device info
    if (payload.deviceInfo) {
      lines.push(`الجهاز: ${payload.deviceInfo}`);
    }

    // Duration
    if (payload.durationSeconds !== undefined) {
      const mins = Math.floor(payload.durationSeconds / 60);
      const secs = payload.durationSeconds % 60;
      lines.push(`مدة البقاء: ${mins} دقيقة و ${secs} ثانية`);
    }

    // Message preview
    if (payload.messagePreview) {
      lines.push(`معاينة الرسالة: ${payload.messagePreview.slice(0, 200)}`);
    }

    // Extra body text
    if (payload.body) {
      lines.push('');
      lines.push(payload.body);
    }

    const text = lines.join('\n');

    const tgResponse = await fetch(
      `https://api.telegram.org/bot${botToken}/sendMessage`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          parse_mode: 'HTML',
        }),
      }
    );

    if (!tgResponse.ok) {
      const errorText = await tgResponse.text();
      console.error('Telegram API error:', tgResponse.status, errorText);
      return new Response(
        JSON.stringify({ error: `Telegram failed: ${tgResponse.status}`, details: errorText }),
        { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    console.error('Notify function error:', err);
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
